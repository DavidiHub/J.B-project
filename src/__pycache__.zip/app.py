from test import Test

Test.test_all()

